﻿using System;
using Konatus.Teste.Application;
using Konatus.Teste.Application.Interfaces;
using Konatus.Teste.Domain.Interfaces.Repositories.Files;
using Konatus.Teste.Domain.Interfaces.Repositories.SqlServer;
using Konatus.Teste.Domain.Interfaces.Services;
using Konatus.Teste.Domain.Services;
using Konatus.Teste.Infrastructure.Files;
using Konatus.Teste.Infrastructure.SqlServer;
using Microsoft.Extensions.DependencyInjection;

namespace Konatus.Teste.Infrastructure.IoC
{
    public abstract class Injector
    {
        public static void Inject(IServiceCollection services)
        {            
            services.AddScoped<Application.Interfaces.IAeronaveService, Application.AeronaveService>();
            services.AddScoped<Application.Interfaces.IModeloAeronaveService, Application.ModeloAeronaveService>();
            services.AddScoped<Domain.Interfaces.Services.IModeloAeronaveService, Domain.Services.ModeloAeronaveService>();
            services.AddScoped<Domain.Interfaces.Services.IAeronaveService, Domain.Services.AeronaveService>();
            services.AddScoped<IModeloAeronaveSqlServerRepository, ModeloAeronaveSqlServerRepository>();
            services.AddScoped<IAeronaveSqlServerRepository, AeronaveSqlServerRepository>();
            services.AddScoped(typeof(IExcelRepository<>), typeof(ExcelRepository<>));            
            services.AddScoped<IAeronaveCsvRepository, AeronaveCsvRepository>();
        }
    }
}