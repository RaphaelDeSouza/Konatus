namespace Konatus.Teste.Domain.Entities
{
    public class Aeronave
    {
        public string Prefix { get; set; }
        public decimal MaxDeparture { get; set; }
        public decimal MaxLanding { get; set; }
        public bool Active { get; set; }
        public string Aircraft { get; set; }
    }
}