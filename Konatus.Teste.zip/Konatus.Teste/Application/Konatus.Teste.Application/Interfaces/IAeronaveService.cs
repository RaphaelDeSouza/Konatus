using System.Collections.Generic;
using System.Threading.Tasks;
using Konatus.Teste.Domain.Entities;

namespace Konatus.Teste.Application.Interfaces
{
    public interface IAeronaveService : IService<Aeronave>
    {
         Task<IEnumerable<Aeronave>> GetActives();
    }
}